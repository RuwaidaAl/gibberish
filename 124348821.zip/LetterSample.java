/*
Author : Ruwaida Al Harrasi
CSCI 1913
LetterSample is a representing a part of a word,
 and the letter that follows it
 */
public class LetterSample {
    private String segment;
    private char nextLetter;
    public static final char STOP = '.';

    /*
    a constructor that takes a value for the segment
    string and the nextLetter char
     */
    public LetterSample(String segment, char nextLetter) {
        this.nextLetter = nextLetter;
        this.segment = segment;
    }


    /*
    returns the segment string for this object
     */
    public String getSegment() {
        return segment;
    }
    /*
     returns the next letter for this object
     */
    public char getNextLetter() {
        return nextLetter;
    }

    public String toString() {
        return "\"" + segment  + "\"" + " -> " + nextLetter ;

    }

    /*
    taking a string and segment size and returns letter
    samples from it
     */

    public static LetterSample[] toSamples(String input, int segmentSize) {

        input += STOP;
        String segment;
        //Split the string into letter segments and fill an array with them.
        LetterSample[] Letters = new LetterSample[input.length()];
        for (int i = 0 ; i < input.length()  ; i++) {

            if( i<=segmentSize ){
                segment = input.substring( 0 , i );
            }
            else {
                segment = input.substring(i-segmentSize , i);
            }
            char nextLetter = input.charAt(i);
            Letters[i] = new LetterSample(segment, nextLetter);
        }
        return Letters;
    }

}
