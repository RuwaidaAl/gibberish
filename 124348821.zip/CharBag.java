/*
Author : Ruwaida Al Harrasi
CSCI 1913
CharBag counts how many times each letter has been added to it’s collection
– and generate random letter from the bag
 */

import java.util.Random;


public class CharBag {
    private char[] letter;
    private int n;

    public CharBag() {
        this.letter = new char[27];
        n = 0;
    }

    /*
     this functions add a char to the charBag
      */
    public void add(char c) {

        //if uppercase letter convert it to lower
        if (!Character.isLetter(c)) {
            c = LetterSample.STOP ;
            //add
            letter[26]++;
            n++;
        }

        // if not an English alphabet convert the char
        // to STOP '.'
        else{
            c = Character.toLowerCase(c);
            //add
            int i= c-'a';
            letter[i]++;
            n++;
        }

    }

    /*
    This function removes a char from the charBag
     */
    public void remove(char c) {
        /// if not an English alphabet convert the char
        // to STOP '.'
        if (!Character.isLetter(c)) {
            c = LetterSample.STOP ;
            //if uppercase letter convert it to lower
        } else {
            c = Character.toLowerCase(c);
        }

        if((getCount(c) > 0 ) &&( c== LetterSample.STOP )){
            letter[26]--;
            n--;

        }
        else if  (getCount(c) > 0 && (Character.isLetter(c))) {
            //removes one of them
               letter[c-'a']--;
               n--;
            }
        }

    /*
    returns how many times a given char is in
    the CharBag
     */
  public int getCount(char c) {
      if (!Character.isLetter(c)) {
          c = LetterSample.STOP;
          return letter[26];
      }
        c = Character.toLowerCase(c);
        return letter[c-'a'];

    }

    /*
    returns the total size of the charBag
     */
    public int getSize() {
        return n ;
    }

    public String toString() {
        String str = "CharBag{";
        for (int i = 0; i < 27; i++) {
            if (i == 26) {
                str = str + '.' + ':' + getCount((char) ('a' + i)) + '}';
            } else {
                str = str + (char) ('a' + i) + ':' + getCount((char) ('a' + i)) + ", ";
            }
        }
        return str;
    }

    /*
    This function will return a randomly chosen char from the
    chars in the char bag.
     */
    public char getRandomChar() {
        if (getSize() > 0) {
            Random random = new Random();
            int randomInt = random.nextInt(getSize());
            for (int i = 0; i < 26; i++) {
                randomInt -= getCount((char) ('a'+i)) ;
                if (randomInt <0) {
                    return  (char) ('a' + i);
                }
            }
            return LetterSample.STOP;
        }
        return LetterSample.STOP;

    }
}