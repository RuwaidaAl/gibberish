/*
Author: Ruwaida Al Harrasi
CSCI 1913

 This class that will be “trained” in how a written
 language works, and will then generate “gibberish”
 words for that language.
 */
public class Gibberisher {
    private Trie<CharBag> model;
    private int segmentLength;
    private int numSamples;

    public Gibberisher(int segmentLength) {
        this.segmentLength = segmentLength;
        model = new Trie<>();
        numSamples = 0;
    }

    /*
    this will return the number of samples used so far to
    train the model
     */
    public int getSampleCount() {
        return numSamples;
    }
    /*
    This function will use LetterSample to generate
    LetterSamples and then add the sample into the model
     */

    public void train(String[] str) {
        // loop over the string and generate letterSamples
        for (int j = 0; j < str.length; j++) {
            String segment = str[j];
            LetterSample[] letterSample = LetterSample.toSamples(segment, segmentLength);
            for (int i = 0; i < letterSample.length; i++) {

                if (model.get(letterSample[i].getSegment()) == null) {
                    model.put(letterSample[i].getSegment(), new CharBag());
                }
                model.get(letterSample[i].getSegment()).add(letterSample[i].getNextLetter());
                numSamples  ++;
            }
        }
    }

    /*
    this function will generate a string and return it
     */
    public String generate() {
        String word = "";

        while ( word.length() ==0 || word .charAt(word .length() - 1) != LetterSample.STOP ) {
            String sample;
            if (word.length() < segmentLength  ) {
                sample = word;
        } else {
                sample = word.substring(word.length() - segmentLength);
            }
             CharBag charBag = model.get(sample);
            char nextLetter = charBag.getRandomChar();
            word += nextLetter;
        }

        return word.substring(0, word.length()-1);
    }

}
