public class test {

    public static void main(String[] args) {



            char c='a';
            System.out.println (c-'a');


    }
}
