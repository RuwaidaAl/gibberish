/*
Author : Ruwaida Al Harrasi
CSCI 1913
Trie Node is a class that's represent a node in a Trie tree
 */
public class TrieNode <T>{
    private T data;
    private  TrieNode<T> [] children;


    public TrieNode(){
        data=null;
        children= new TrieNode[26];
    }
    //this method returns a data
    public T getData(){
        return data;
    }
    //this method sets the data
    public void setData(T data){
        this.data =data;
    }

    /*
    this method returns TrieNode<T> of the given letter
     */
    public TrieNode<T> getChild(char letter) {
        if (!Character.isLowerCase(letter)) {
            return null;
        }
        else if (children[(int) (letter - 'a')]==null) {
            TrieNode<T> newNode = new TrieNode<>();
            children[(int) (letter - 'a')]=newNode;
            return newNode;
        }
        else{
            return children[(int) (letter - 'a')];
        }


    }

    /*
    this will return the number of nodes in the tree
     */
    public int getTreeSize(){
      int count=0;
      for(int i=0;i< children.length;i++){
          if(children[i] != null) {
              count += children[i].getTreeSize();
          }
      }
      return count+1;
    }
}
