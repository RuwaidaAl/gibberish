/*
Author : Ruwaida Al Harrasi
CSCI 1913
a class that behaves like a dictionary
 */
public class Trie <T>{
    private TrieNode<T> root;

    public Trie (){
        root = new TrieNode<>();
    }

    /*
    This function will take a string and returns
    the right trieNode
     */
    public TrieNode<T> getNode( String str){
        TrieNode<T> newRoot= root;
        for( int i=0; i<str.length(); i++){
            newRoot= newRoot.getChild(str.charAt(i));
        }
        return newRoot;
    }
    /*
     this returns the data currently stored on the
     TrieNode associated with the string
     */
    public T get(String str){

        return getNode(str).getData();
    }
    /*
    This method sets the data currently stored on the
    TrieNode associated with the input string to the
    T value provided
     */
    public T put(String str, T data) {
       getNode(str).setData(data);
       return data;
    }

    /*
    this will return the root
     */
    public TrieNode<T> getRoot(){
        return root;
    }
}
